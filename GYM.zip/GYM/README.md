# GYM 🏋️

Registro automático de tus visitas al gimnasio. Cada vez que llegas o sales
(detectado por geolocalización con un Atajo de iPhone), se sube un archivo
JSON a `gym_events/`. GitHub Actions procesa esos eventos y mantiene
actualizado `data/gym_sessions.csv` con tus sesiones (hora de entrada, salida
y duración).

```
GYM/
│
├── gym_events/                        # Eventos crudos (entry/exit) subidos desde el iPhone
│   ├── 2026-09-11_091532_entry.json
│   ├── 2026-09-11_104718_exit.json
│   └── ...
│
├── data/
│   └── gym_sessions.csv               # Sesiones procesadas (se regenera automáticamente)
│
├── scripts/
│   └── process_gym_sessions.py        # Empareja entry/exit y genera el CSV
│
└── .github/
    └── workflows/
        └── update_gym_sessions.yml    # Corre el script en cada push a gym_events/
```

## 1. Subir este proyecto a tu repo

Ya tienes el repo `franciscolodi/GYM` creado (por ahora solo con README).
Desde la carpeta descomprimida:

```bash
cd GYM
git init
git remote add origin https://github.com/franciscolodi/GYM.git
git fetch origin
git checkout -b main --track origin/main   # trae el README existente
git add .
git commit -m "feat: estructura inicial del proyecto GYM"
git push origin main
```

Si `git checkout -b main --track origin/main` da conflicto porque el README
remoto y el local no coinciden, simplemente:

```bash
git pull origin main --allow-unrelated-histories
git push origin main
```

## 2. Cómo funciona el pipeline

1. El Atajo de iPhone crea un archivo `.json` en `gym_events/` vía la API de
   GitHub (contenidos → "crear/actualizar archivo") cada vez que llegas o
   sales del gimnasio.
2. Ese `push` dispara el workflow `update_gym_sessions.yml`.
3. El workflow ejecuta `scripts/process_gym_sessions.py`, que lee **todos**
   los eventos, los empareja en sesiones y regenera `data/gym_sessions.csv`.
4. El workflow hace commit y push del CSV actualizado.

Formato de cada evento (el nombre del archivo es solo legible, el contenido
manda):

```json
{
  "type": "entry",
  "timestamp": "2026-09-11T09:15:32"
}
```

Puedes correr el script localmente en cualquier momento:

```bash
python scripts/process_gym_sessions.py
```

## 3. Configurar el Atajo en el iPhone (17 / iOS 26)

Necesitas un **Personal Access Token** de GitHub (classic, con permiso
`repo`, o fine-grained con permiso de escritura sobre contenidos de este
repo). Créalo en GitHub → Settings → Developer settings → Personal access
tokens. Guárdalo, no lo vas a volver a ver.

Vas a crear **dos** atajos casi idénticos: `Gym Entry` y `Gym Exit`.

### Pasos dentro de la app Atajos

1. **Fecha actual** → acción "Fecha".
2. **Formatear fecha** dos veces a partir de esa fecha:
   - Una con formato personalizado `AAAA-MM-dd'T'HH:mm:ss` → esto será el
     `timestamp` ISO.
   - Otra con formato personalizado `AAAA-MM-dd_HHmmss` → esto será para el
     nombre de archivo.
3. **Texto** → arma el contenido JSON:
   ```
   {"type":"entry","timestamp":"[Fecha ISO]"}
   ```
   (usa `exit` en el atajo de salida)
4. **Codificar** → "Codificar en Base64" ese texto.
5. **Texto** → arma la ruta del archivo:
   ```
   gym_events/[Fecha nombre archivo]_entry.json
   ```
6. **Obtener contenido de URL**:
   - URL:
     ```
     https://api.github.com/repos/franciscolodi/GYM/contents/[Ruta del archivo]
     ```
   - Método: `PUT`
   - Encabezados:
     - `Authorization` → `token TU_PERSONAL_ACCESS_TOKEN`
     - `Accept` → `application/vnd.github+json`
   - Cuerpo de la solicitud → **JSON**, con estos campos:
     - `message` (Texto): `"registro entrada gym"`
     - `content` (Texto): el resultado del paso 4 (Base64)
     - `branch` (Texto): `main`

Duplica el atajo, cambia `entry` por `exit` en los pasos 3 y 5 (y el mensaje
del commit si quieres), y ya tienes `Gym Exit`.

### Automatizarlo por ubicación (sin tocar el teléfono)

En la app **Atajos → Automatización → Crear automatización personal**:

- **Al llegar** → elige la ubicación del gimnasio → "Ejecutar atajo" →
  `Gym Entry` → activa **"No preguntar antes de ejecutar"** para que corra
  solo, en segundo plano.
- **Al salir** → misma ubicación → "Ejecutar atajo" → `Gym Exit` → mismo
  ajuste.

Con eso, cada vez que entres o salgas del radio del gimnasio, el iPhone sube
el evento solo, sin que abras la app.

## 4. Notas

- Los eventos nunca se borran de `gym_events/`; son el log crudo. El CSV en
  `data/` se regenera completo cada vez a partir de ellos, así que si algún
  evento se corrompe o duplica, puedes editarlo/borrarlo y volver a correr
  el workflow (`Actions → Update Gym Sessions → Run workflow`).
- Si alguna vez ves `status = sin_salida` o `sin_entrada` en el CSV, es que
  un evento no tuvo su par (por ejemplo, el teléfono no detectó la salida).
